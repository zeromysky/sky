#!/usr/bin/python
#-*-coding:utf-8-*-
# 监控服务
# yudf
import sys
reload(sys)
sys.setdefaultencoding('utf-8')

import lib
import time,json
# /home/fault_detection

'''
memcache 	连接是否超时 读数据 写数据 当前连接数
redis 		连接是否超时 读数据 写数据 当前连接数
数据库 		连接是否超时 读数据 写数据 当前连接数 锁表 当前进程中大于5s的sql
接口S2,S3,S4  连接是否超时 获取数据   

es 			连接是否超时 ==
doc current get num       		当前正在运行的 get 请求数
doc total get num       		总的 get 请求次数
http current open num       	当前打开的 http 连接数
http total opened num       	打开 http 的总连接数
transport server open num   	为集群通信打开的连接数
thread_pool search threads      在 search 线程池总的线程数
thread_pool search queue       	在 search 线程池排队的线程数
thread_pool search active       在 search 线程池活跃的线程数

ip        port heapPercent  heapMax ramPercent ramMax 
127.0.0.1 9300          29 1007.3mb         33  1.8gb 


green	所有主要分片和复制分片都可用
yellow	所有主要分片可用，但不是所有复制分片都可用
red		不是所有的主要分片都可用

test1 : green
yl1001search : green
test2 : yellow
--------------------
status
yellow
number_of_replicas
1
unassigned_shards
5
number_of_shards
5
active_primary_shards
5
relocating_shards
0
active_shards
5
initializing_shards
0
--------------------



'''


'''

python-memcached 扩展
wget https://pypi.python.org/packages/f7/62/14b2448cfb04427366f24104c9da97cf8ea380d7258a3233f066a951a8d8/python-memcached-1.58.tar.gz#md5=23b258105013d14d899828d334e6b044
tar -zxvf python-memcached-1.58.tar.gz
cd python-memcached-1.58
python setup.py install

python-redis 扩展
wget https://pypi.python.org/packages/source/r/redis/redis-2.9.1.tar.gz
tar xvzf redis-2.9.1.tar.gz
cd redis-2.9.1
python setup.py install

python-mysql 扩展
wget https://pypi.python.org/packages/9a/81/924d6799494cf7fb24370335c2f782088d6ac4f79e4137d4df94cea3582c/MySQL-python-1.2.3.tar.gz#md5=215eddb6d853f6f4be5b4afc4154292f
tar xvzf MySQL-python-1.2.3.tar.gz
cd MySQL-python-1.2.3
python setup.py install

可能出现的错误
1）mysql_config: command not found

	find / -name mysql_config 
	/usr/local/mysql-5.0.67/bin/mysql_config
	setup_posix.py
	mysql_config.path = "/usr/local/mysql-5.0.67/bin/mysql_config"

2）error: command 'gcc' failed with exit status 1
yum install python-devel



'''

print "====接口测试==开始===="
print 
class_fun = ['trade','select']
to_data = {'whereStr':'1=1','selectStr':'idd'}
user = ['company','com889900']
host = 'http://s2.job1001.com/webservice/index.php?'
print "----------------------------"
print "|s2|start|"
res = lib.surl(class_fun,to_data,host,user)
print res
if str(res).find('idd') != -1:
	print "success s2"
print "|s2|end|"
print "----------------------------"
print 
print "----------------------------"
print "|s3|start|"
host = 'http://s3.job1001.com/webservice/index.php?'
res = lib.surl(class_fun,to_data,host,user)
print res
if str(res).find('idd') != -1:
	print "success s3"
print "|s3|end|"
print "----------------------------"
print 
print "----------------------------"
print "|s4|start|"
host = 'http://s4.job1001.com/webservice/index.php?'
res = lib.surl(class_fun,to_data,host,user)
print res
if str(res).find('idd') != -1:
	print "success s4"
print "|s4|end|"
print "----------------------------"
print 
print "====接口测试==结束===="



now_time = str(int(time.time()))+'_test'

memcache_config = lib.get_config('conf.ini','memcache')
config_open = memcache_config['open']
del memcache_config['open']
if config_open=='1' :
	print 
	print "====memcache==开始===="
	print 
	memcache_config = lib.unique_value(memcache_config)
	import memcache
	do_memcache = []
	for memcache_str in memcache_config:

		memcache_host_port = memcache_str
		print "----------------------------"
		print "|"+memcache_str+"|start|"
		try:
			
			mc = memcache.Client([memcache_host_port], debug=True)
			mc.set(now_time,'1')
			res = mc.get(now_time)

			mc_status = mc.get_stats()
			print "Current Connect Num: "+str(mc_status[0][1]['curr_connections'])

		except Exception, e:
			print "-------error-start--------"
			print memcache_str +' '+ str(e.message)
			print "-------error-end--------"
			print 

		else:
			if res=='1' :
				print "success set and get and del "+memcache_str
				mc.delete(now_time)
		
		print "|"+memcache_str+"|end|"
		print "----------------------------"
		print 

		pass
	print "====memcache==结束===="


print 


redis_config = lib.get_config('conf.ini','redis')
open_config = redis_config['open']
del redis_config['open']

if open_config=='1':
	print "====redis==开始===="
	print 
	redis_config = lib.unique_value(redis_config)
	import redis

	for redis_str in redis_config:

		redis_host_port = redis_str
		print "|"+redis_str+"|start|"
		print "----------------------------"
		
		try:

			redis_host_port_list = redis_host_port.split(':')
			r = redis.Redis(host=redis_host_port_list[0],port=redis_host_port_list[1])
			r_status = r.execute_command('info').split("\r\n")
			for x in r_status:
				if x.find('connected_clients')!=-1:
					print x
				pass
			r.set(now_time,'1')
			res = r.get(now_time)
		
		except Exception, e:
			print "-------error-start--------"
			print redis_str + str(e.message)
			print "-------error-end--------"
			print 
			

		else:
			if res=='1' :
				print "success set and get and del "+redis_str
				r.delete(now_time)

		print "|"+redis_str+"|end|"
		print "----------------------------"
		print 
		pass

	print "====redis==结束===="

print 


mysql_config = lib.get_config('conf.ini','mysql')
open_config = mysql_config['open']
del mysql_config['open']

if open_config == "1":
	print "====mysql==开始===="
	print 
	mysql_config = lib.unique_value(mysql_config)

	import MySQLdb

	for mysql_str in mysql_config:
		
		host_port,user,passwd,db  = mysql_str.split('/')
		if len(host_port.split(':'))>1:
			host = host_port.split(':')[0]
			port = int(host_port.split(':')[1])
		else:
			host = host_port
			port = 3306

		print "----------------------------"
		print "|"+mysql_str+"|start|"
		

		try:
			mysql_status = '1';
			conn= MySQLdb.connect(
				host=host,
				port =port,
				user=user,
				passwd=passwd,
				db = db,
			)
			cur = conn.cursor()

			#锁表
			print "check lock table"
			res = cur.fetchmany(cur.execute("SHOW OPEN TABLES where In_use > 0"))
			if res:
				lib.dump(res)
				res = cur.fetchmany(cur.execute("SHOW STATUS like 'Table%'"))
				lib.dump(res)
				mysql_status = '0';
			pass

			print "check status"
			res = cur.fetchmany(cur.execute("SHOW FULL PROCESSLIST"))

			print "Current Connect Num: "+str(len(res))

			for x in res:
				_host = x[2]
				_db = x[3]
				_type = x[4]
				_time = x[5]
				_sql = x[6]

				if _type.upper()=='QUERY' and _time>5 :
					print "host: "+_host+" time > 5s query :"+str(_sql)
					mysql_status = '0';
				if _type.upper()=='LOCKED':
					print "host: "+_host+" LOCKED ";
					mysql_status = '0';

				pass


			if mysql_status == '0':continue

			#表
			print 'check create table'
			check_fault_job1001 = 'check_fault_job1001'+now_time
			cur.execute("CREATE TABLE "+check_fault_job1001+" (id int)")
			conn.commit()
			print 'check create table - ok'

			print 'check insert'
			cur.execute("INSERT INTO  "+check_fault_job1001+"  (`id`) VALUES ('1')")
			conn.commit()
			print 'check insert - ok'

			print 'check select'
			cur.execute("SELECT * FROM  "+check_fault_job1001+"  LIMIT 1")
			info = cur.fetchone()
			if info :
				if info[0] == 1:
					print 'check select - ok'
					cur.execute("DROP TABLE IF EXISTS "+check_fault_job1001+"" )
					conn.commit()

		except Exception, e:
			print "-------error-start--------"
			print host,
			print port,
			print user,
			print passwd,
			print db,
			print mysql_str + str(e)
			print "-------error-end--------"
			print 

		else:
			if mysql_status=='1' :
				print "success create and insert and select and del  "+mysql_str

		print "|"+mysql_str+"|end|"
		print "----------------------------"
		print 
		pass

	print "====mysql==结束===="

print


es_config = lib.get_config('conf.ini','es')
config_open = es_config['open']
del es_config['open']

if config_open == "1":
	print "====ES==开始===="
	print 
	es_config = lib.unique_value(es_config)

	for es_str in es_config:
		print "----------------------------"
		print "|"+es_str+"|start|"
		try:
			url = 'http://'+es_str+'/_nodes/stats/'
			res = lib.http_get(url)
			res=json.loads(res,encoding='UTF-8')

			for x in res['nodes']:
				print "----"+str(x)+"----" 
				print "doc current get num : "+str(res['nodes'][x]['indices']['get']["current"])
				print "doc total get num : "+str(res['nodes'][x]['indices']['get']["total"])
				print "http current open num : "+str(res['nodes'][x]['http']['current_open'])
				print "http total opened num : "+str(res['nodes'][x]['http']['total_opened'])
				print "transport server open num : "+str(res['nodes'][x]['transport']['server_open'])
				print "thread_pool search threads : "+str(res['nodes'][x]['thread_pool']['search']['threads'])
				print "thread_pool search queue : "+str(res['nodes'][x]['thread_pool']['search']['queue'])
				print "thread_pool search active : "+str(res['nodes'][x]['thread_pool']['search']['active'])
				pass

			url = 'http://'+es_str+'/_cat/nodes?v&h=ip,port,heapPercent,heapMax,ramPercent,ramMax'
			res2 = lib.http_get(url)
			print res2


			url = 'http://'+es_str+'/_cluster/health?level=indices'
			res3 = lib.http_get(url)
			res3=json.loads(res3,encoding='UTF-8')

			for x in res3['indices']:
				print x +" : "+ str(res3['indices'][x]['status'])
				if str(res3['indices'][x]['status']) != 'green':
					print "--------------------"
					lib.dump(res3['indices'][x])
					print "--------------------"
					print  
				pass
			print 

		except Exception, e:
			print '----error--start----'
			print es_str+" "+str(e)
			print '----error--end----'
			print 
		pass

	print "|"+es_str+"|end|"
	print "----------------------------"
	print 

	print "====ES==结束===="


