#!/usr/bin/python
#-*-coding:utf-8-*-
# 监控服务
import sys
reload(sys)
sys.setdefaultencoding('utf-8')

import ConfigParser

import os,time,datetime
from urlparse import urlparse
import urllib,urllib2
import json
import httplib

#获取配置
def get_config(fileName=None,group=None):
    if fileName==None : return None
    if group==None : return None
    cf = ConfigParser.ConfigParser()
    cf.read(fileName)
    conf_list = cf.items(group)
    conf_option = cf.options(group)
    out = {}
    for x in conf_list:
        out[x[0]] = x[1]
    return out

#去重
def unique_value(config_dict):
    out = []
    if config_dict:
        for x in config_dict:
            if config_dict[x] not in out:
                out.append(config_dict[x])
            pass
    return out

#输出
def dump(var):
    if var:
        if isinstance(var,list) or isinstance(var,tuple) :
            for x in var:
                print x
                pass
            pass
        if isinstance(var,dict):
            for x in var:
                print str(x) 
                print var[x]
                pass
            pass

def parsepath (pageurl):
    res={}
    print pageurl
    if pageurl[0:7]=='http://':
        urlp = urlparse(pageurl)
        fpos=pageurl.find('/',8)
        res['scheme']=urlp.scheme
        res['netloc']=urlp.netloc
    else:
        fpos=pageurl.find('/')
    pos=-1
    if pageurl[-1:]!='/':  pos=pageurl.rfind('/')
    if pos==-1 : pos=len(pageurl)

    if pos!=len(pageurl): res['filename']=pageurl[pos+1:len(pageurl)]
    if fpos!=-1 : res['dir']=pageurl[fpos:pos+1]

    if res.get('filename')!=None:
        filename=res.get('filename')
        kpos=filename.rfind('.')
        if kpos!=-1:
            res['ext']=filename[kpos+1:len(filename)]

    #print res
    return res

def http_post(data,target):
    poststr=""
    murl=parsepath(target)
    headers = {"Content-type": "application/x-www-form-urlencoded" , "Accept": "text/plain"}
    if data!=None:
        data['python_post'] = 1
        poststr=urllib.urlencode(data)
    # print poststr
    post_flag='1'
    conn=None
    try:
        conn = httplib.HTTPConnection(murl['netloc'],'80',timeout=30)
        conn.request("POST",target,poststr,headers)
        response = conn.getresponse()
        res= response.read()
        # if res.find("OK")!=-1:
        #     post_flag='1'
        # else:
        post_flag=res
    except Exception, e:
        print e
    finally:
        if conn:
            conn.close()

    return post_flag


def surl(func,data,host='http://192.168.60.164/webservice/indexp.php?',user=['email','email889900']):

    target=host+"op="+func[0]+'&func='+func[1]+"&user="+user[0]+"&pwd="+user[1]+"&gtype=http&rtype=json";
    print target
    res=http_post(data,target)
    print data
    # print res
    # arr={}
    # try:
    #     if res!=None and res.strip()!='':
    #         arr=json.loads(res,encoding='UTF-8')
    #     else:
    #         arr=None
    # except Exception, e:
    #     print e
    return res

def http_get(url,data=None):
    req = urllib2.Request(url)
    req.add_header('User-Agent','Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.82 Safari/537.36')
    response = urllib2.urlopen(req)
    html=response.read()
    return html